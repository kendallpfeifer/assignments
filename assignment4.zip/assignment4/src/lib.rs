use std::fmt;

pub struct LinkedList<T> {
    head: Option<Node<T>>,
    len: i32
}

pub struct Node<T> {
    pub next: Option<Box<Node<T>>>,
    pub data: T
}

impl<T> LinkedList<T> {

    pub fn new()-> LinkedList<T> {
        LinkedList { head: None, len: 0}
    }

    pub fn len(&mut self) -> i32 {
        self.len
    }

    pub fn get_tail(curr: &mut Node<T>, item: T) -> Option<Box<Node<T>>>{
        match &curr.next {
            None => {
                let new_node = Box::new( Node {
                    next: None, 
                    data: item
                });
                return curr.next.replace(new_node);
            },
            Some(x) => {
                return LinkedList::get_tail(&mut *x, item);
            }
        }
    }

    pub fn push(&mut self, item: T) {
        self.len += 1;
        let mut _tail = None;
        match &mut self.head {
            Some(x) => _tail = LinkedList::get_tail(&mut *x, item),
            None => self.head = Some(Node {
                next: None, 
                data: item
            })
        };
        // let mut tail_node = LinkedList::get_tail(self.head.as_ref().unwrap());
        // tail_node.next = Some(Box::new(new_node));
        
    }

    pub fn get_pre_to_tail(curr: &Node<T>) -> Node<T>{
        match (*curr.next.as_ref().unwrap()).next {
            None => {
                let n = Node {
                    next: curr.next, 
                    data: curr.data
                };
                return n;
            }
            Some(x) => {
                return LinkedList::get_pre_to_tail(&*x);
            }
        }
    }

    pub fn get_tail_noparam(curr: Node<T>) -> Node<T> {
        match curr.next {
            None => {
                return curr
            },
            Some(x) => {
                return LinkedList::get_tail_noparam(*x);
            }
        }
    }

    pub fn pop(&mut self) -> Option<T> {
        let result = None;
        match self.head {
            None => return result, 
            Some(x) => {
                let to_remove = LinkedList::get_tail_noparam(x);
                let mut prev_node = LinkedList::get_pre_to_tail(&x);
                prev_node.next = None; 
                return Some(to_remove.data)
            }
        };
        // let mut prev_node = LinkedList::get_pre_to_tail(self.head.unwrap());
        // let to_remove = LinkedList::get_tail(self.head.as_ref().unwrap());
    }
}


